public class Main {


    public static void main(String[] args){


        Trabajador trabajador = new Trabajador("Roberto", "Rivas", "15421652-5",456789,64);
        Trabajador trabajador2 = new Trabajador("Bastián", "Mariangel", "18907352-6",95123456,28);
        Trabajador trabajador3 = new Trabajador("Patricio", "Bonnin", "16228852-2",32698789,25);

        System.out.println(trabajador.toString());
        System.out.println(trabajador2.toString());
        System.out.println(trabajador3.toString());



    }
}
